ReadMeIcons.txt

  This ReadMeIcons folder contains more icon (.ico) files, many for use with
older versions of EQ3/6.

-----

