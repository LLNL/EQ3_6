ReadMeManuals.txt

  This ReadMeManuals folder contains the Version 7 series manuals and the official Yucca
Mountain Project manual for version 8.0. The official Livermore manual for version 8.0
is not yet available. All manuals are in PDF format. There is no separate manual for 8.0a.

  See also the text files in the Text folder.

-----

