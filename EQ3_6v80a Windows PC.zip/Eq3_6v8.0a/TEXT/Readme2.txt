 Readme2.txt     Last revised 06/07/13

 EQ3/6, A Software Package for Geochemical Modeling
  Version 8.0a


 -----------------------------------------------------------------------------

                          RECOMMENDED FORM OF CITATION

   The following form is recommended for formal citation of this software:

     Wolery, T.J., 2013, EQ3/6 - Software for Geochemical Modeling,
       Version 8.0a, LLNL-CODE-2013-683958, Lawrence Livermore National
       Laboratory, Livermore, California.

 -----------------------------------------------------------------------------

                         FURTHER INFORMATION

   For further information, consult the other ".txt" files included in this
 distribution package. The following is a list of all text files:

   Readme.txt      The main readme file, with licensing information
   Contents.txt:   A list of the package contents
   FAQ.txt:        Frequently asked questions
   Install.txt:    Installation instructions
   News.txt:       News
   Readme2.txt     The file you are now reading
   Run.txt:        Instructions for running the software

 You may also consult the manuals in the Manuals folder.

 -----------------------------------------------------------------------------
 end of the Readme2.txt file
