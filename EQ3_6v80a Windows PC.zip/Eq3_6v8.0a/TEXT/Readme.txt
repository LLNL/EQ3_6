 Readme.txt     Last revised 12/13/10

 EQ3/6, A Software Package for Geochemical Modeling
  Version 8.0a

   *** This file has not been updated for 8.0a, which is a minor update
       of version 8.0. It contains some changes made for the
       WIPP program ***

   Copyright (c) 1987, 1990-1993, 1995, 1997, 2002 The Regents of the University
   of California, Lawrence Livermore National Laboratory. All rights
   reserved.

     This software was produced under the Designated Unclassified
   Subject Area (DUSA) "Yucca".

     This software was granted Code-In-Development Limited Release to
   licensees only with an Export Controlled Information Restriction
   on December 2, 2002. This release is identified as UCRL-CODE-2003-009.

     This work was produced at the University of California,
   Lawrence Livermore National Laboratory (UC LLNL) under
   contract no. W-7405-ENG-48 (Contract 48) between the U.S.
   Department of Energy (DOE) and The Regents of the University of
   California (University) for the operation of UC LLNL. The rights
   of the Federal Government are reserved under Contract 48 subject
   to the restrictions agreed upon by the DOE and University
   as allowed under DOE Acquisition Letter 97-1.


                          DISCLAIMER

     This computer code was prepared as an account of work
   sponsored by an agency of the United States Government.
   Neither the United States Government nor the University of
   California nor any of their employees, makes any warranty,
   express or implied, or assumes any liability or responsibility
   for the accuracy, completeness, or usefulness of any
   information, apparatus, product, or process disclosed, or
   represents that its use would not infringe privately-owned
   rights. Reference herein to any specific commercial products,
   process, or service by trade name, trademark, manufacturer,
   or otherwise, does not necessarily constitute or imply its
   endorsement, recommendation, or favoring by the United States
   Government or the University of California. The views and
   opinions of authors expressed herein do not necessarily state
   or reflect those of the United States government or the
   University of California, and shall not be used for
   advertising or product endorsement purposes.


                          NOTIFICATION OF COMMERCIAL USE

     Commercialization of this product is prohibited without
   notifying the Department of Energy (DOE)or Lawrence Livermore
   National Laboratory (LLNL).
   

                          NOTICE

     This is the official LLNL release of the software. This is not an official
   copy of the software as qualified for the Yucca Mountain Project. Users
   working for the Yucca Mountain Project must obtain the software from
   Software Configuration Management in Las Vegas, Nevada.


 -----------------------------------------------------------------------------

                          RECOMMENDED FORM OF CITATION

   The following form is recommended for formal citation of this software:

     Wolery, T.J., 2002, EQ3/6 - Software for Geochemical Modeling,
       Version 8.0, UCRL-CODE-2003-009, Lawrence Livermore National
       Laboratory, Livermore, California.

 -----------------------------------------------------------------------------


                          CODE CUSTODIAN

   Address correspondence regarding the the software to:

   Dr. Thomas J. Wolery, L-631
   Lawrence Livermore National Laboratory
   P.O. Box 808
   Livermore, CA 94550

   Telephone: (925) 422-5789
   FAX: (925) 422-2105
   E-mail: wolery@llnl.gov


 -----------------------------------------------------------------------------


                          LICENSING

   This software is licenced by LLNL through the LLNL Industrial Partnerships and
 Commercialization (IPAC) Office. Requests
 should be addressed to:

   Industrial Partnerships and Commercialization
   L-795
   Attention: EQ3/6 Licensing
   Lawrence Livermore National Laboratory
   P.O. Box 808
   Livermore, CA 94550

   Telephone: (925) 422-1511
   FAX: (925) 423-8988
   E-mail: none

   The Industrial Partnerships and Commercialization Office has complete
 authority over the licensing process. It sets and collects the fees.
 Both academic and commercial licenses are available. Contact IPAC for
 current information.


 -----------------------------------------------------------------------------


                         FURTHER INFORMATION

   For further information, consult the other ".txt" files included in this
 distribution package. The following is a list of all text files:

   Contents.txt:   A list of the package contents
   FAQ.txt:        Frequently asked questions
   Install.txt:    Installation instructions
   News.txt:       News
   Readme.txt      The file you are now reading
   Run.txt:        Instructions for running the software


 -----------------------------------------------------------------------------
 end of the Readme.txt file
