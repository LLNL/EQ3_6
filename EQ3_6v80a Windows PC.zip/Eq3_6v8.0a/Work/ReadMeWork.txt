ReadMeWork.txt

  This Work folder is a location in which you may perform installation
verification or otherwise run the software.

-----
