ReadMeCmdLineShortcuts.txt

  *** For Windows NT, extract the 8.0 shortcut for NT and modify it for 8.0a ***
  *** This can only be done on an NT system ***

  This directory (CmdLineShortcuts) contains shortcuts for opening a command line
(DOS) window in which to run EQ3/6. These shortcuts are specific to given versions
of the Windows OS (95/98/NT4/2000/XP). The "9x" shortcut is used for both Windows
95 and 98. The Windows 2000 and XP shortcuts are very similar, differing only in
the path to CMD.EXE specified in the Properties. The Properties are editable by
right-clicking on an icon and choosing "Properties".

  Use the XP shortcut for Vista and Windows 7.

  The Properties are preconfigured according to the usual locations of command.com
and cmd.exe in the system folders, and such that the EQ3/6 Version 8.0 directory is
C:\EQ3_6v8.0. If the software is installed such that this is not the path to this
directory (or the directory itself is renamed to something else), then the user must
change all references to the directory and its path in both the shortcut Properties
and the batch file eq36cfg.bat, which resides in the EQ3/6 Version 8.0 directory.
Changing the drive letter is fairly simple. Changing the path otherwise may
require advanced Windows/DOS skills. We suggest that people without these skills
particularly avoid any path changes involving elements with contained spaces
(e.g., "Program Files") or elements consisting of more than eight characters
(e.g., "GeochemistryPrograms").

  Once a shortcut is properly configured (and is verified to be working), a copy
can be placed in any convenient location, such as the Windows Desktop or the Windows
taskbar. If desired, multiple shortcuts can be employed, configured to open the
command line window in different working folders (the target folder is specified
in the shortcut Properties).

  Safe copies of the shortcuts are contained in the zip file v8CmdLineShortcuts.zip.

-----