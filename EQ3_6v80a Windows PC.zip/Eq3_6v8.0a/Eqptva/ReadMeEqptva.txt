ReadMeEqptva.txt

  This Eqptva folder contains the thermodynamic data files data0.ymp,
data0.ypf, data0.hmw, and data0.5kb from the Db folder. It also contains
all of the output files produced by running the EQPT code on these data
files. These files are included to provide a baseline, should it become
necessary to verify the proper operation of EQPT.

-----

